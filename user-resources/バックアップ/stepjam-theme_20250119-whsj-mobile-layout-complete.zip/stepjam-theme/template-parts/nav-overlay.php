<?php
/**
 * Template part for displaying navigation overlay
 * 
 * @package STEPJAM_Theme
 */
?>

<!-- Navigation Overlay (Node: 203:269) - height: 100vh レスポンシブ対応 -->
<nav id="nav-overlay" 
     class="fixed top-0 left-0 bg-black bg-opacity-50 z-[9999] hidden" 
     style="height: 100vh; width: 100%; max-width: 1200px; overflow: hidden;"
     data-acf="nav-overlay">
    
    <!-- Nav Content Container - Flexbox縦並びレイアウト -->
    <div class="flex flex-col justify-between items-start p-0 h-full w-full" 
         data-name="nav-open">
        
        <!-- Nav Header Area -->
        <div class="flex flex-row gap-11 items-center justify-start w-full p-0" 
             style="height: 96.12px;" 
             data-name="nav-header">
            
            <!-- Close Button -->
            <button id="nav-close-btn" 
                    class="block cursor-pointer relative shrink-0" 
                    style="width: 173.08px; height: 96.12px;" 
                    data-name="nav-bt_close"
                    aria-label="Close Navigation">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/nav/nav-bt-close.svg'); ?>" 
                     alt="Close Navigation" 
                     class="block max-w-none w-full h-full" />
            </button>
            
            <!-- STEPJAM Logo -->
            <div class="relative shrink-0" 
                 style="width: clamp(80px, 106.67px, 150px); height: clamp(16px, 21.47px, 30px);" 
                 data-name="nav-sjlogo">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/nav/nav-sjlogo.svg'); ?>" 
                     alt="<?php echo esc_attr(get_bloginfo('name')); ?> Logo" 
                     class="block max-w-none w-full h-full" />
            </div>
            
        </div>
        
        <!-- Menu Area -->
        <div class="flex flex-col gap-14 items-end justify-start w-full overflow-hidden pl-10 pr-0 py-0" 
             data-name="menu-area">
            
            <!-- Desktop Nav Menu -->
            <div class="flex flex-col justify-start items-start w-full min-w-80 px-px py-0 space-y-6" 
                 data-name="desk-nav-menu">
                
                <!-- HOME Menu Item -->
                <button class="nav-menu-item text-left text-white hover:text-cyan-400 transition-colors cursor-pointer" 
                        style="font-family: 'Noto Sans JP', sans-serif; font-weight: 800; font-size: 2.625rem;"
                        data-scroll-target="hero-section">
                    HOME
                </button>
                
                <!-- WHAT SJ Menu Item -->
                <button class="nav-menu-item text-left text-white hover:text-cyan-400 transition-colors cursor-pointer" 
                        style="font-family: 'Noto Sans JP', sans-serif; font-weight: 800; font-size: 2.625rem;"
                        data-scroll-target="whsj-section">
                    WHAT SJ
                </button>
                
                <!-- LIBRARY Menu Item with Dropdown -->
                <div class="library-dropdown relative">
                    <button class="nav-menu-item text-left text-white hover:text-cyan-400 transition-colors cursor-pointer flex items-center" 
                            style="font-family: 'Noto Sans JP', sans-serif; font-weight: 800; font-size: 2.625rem;"
                            data-scroll-target="lib-top-section"
                            id="library-toggle">
                        LIBRARY
                        <span class="ml-2 transform transition-transform duration-200" id="library-arrow">▼</span>
                    </button>
                    
                    <!-- Dropdown Menu -->
                    <div class="library-submenu ml-4 mt-2 space-y-2 hidden" id="library-submenu">
                        <button class="nav-submenu-item text-left text-white font-sans text-base hover:text-cyan-400 transition-colors cursor-pointer block" 
                                data-scroll-target="lib-list-section"
                                data-tab="tokyo">
                            TOKYO
                        </button>
                        <button class="nav-submenu-item text-left text-white font-sans text-base hover:text-cyan-400 transition-colors cursor-pointer block" 
                                data-scroll-target="lib-list-section"
                                data-tab="osaka">
                            OSAKA
                        </button>
                    </div>
                </div>
                
            </div>
            
            <!-- Desktop Nav Footer Menu -->
            <div class="flex flex-row gap-8 items-start justify-start w-full min-w-80 p-0" 
                 style="height: 60px;" 
                 data-name="desk-nav_footermenu">
                
                <a href="https://rootz-adl.com/company/" 
                   target="_blank"
                   class="text-left text-white font-sans text-lg hover:text-cyan-400 transition-colors cursor-pointer"
                   rel="noopener noreferrer">
                    会社概要
                </a>
                
                <a href="<?php echo esc_url(stepjam_get_site_option('privacy_policy_url', 'https://rootz-adl.com/privacy-policy-2/')); ?>" 
                   target="_blank"
                   class="text-left text-white font-sans text-lg hover:text-cyan-400 transition-colors cursor-pointer"
                   rel="noopener noreferrer">
                    個人情報
                </a>
                
            </div>
            
        </div>
        
        <!-- Nav Item Obi (Bottom Decoration) -->
        <div class="flex flex-row gap-2.5 items-end justify-start w-full p-0 opacity-20" 
             data-name="nav-item_obi">
            
            <div class="relative shrink-0" 
                 style="width: clamp(800px, 1215.55px, 100%); height: clamp(30px, 37.03px, 45px);" 
                 data-name="open-obi">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/nav/open-obi.svg'); ?>" 
                     alt="Navigation Decoration" 
                     class="block max-w-none w-full h-full" />
            </div>
            
        </div>
        
    </div>
    
</nav>