
class STEPJAMreApp {
    constructor() {
        this.isDesktop = window.innerWidth >= 768;
        this.init();
    }

    init() {
        
        this.bindEvents();
        this.initMainContent();
        
        // Responsive check on resize
        window.addEventListener('resize', () => {
            const wasDesktop = this.isDesktop;
            this.isDesktop = window.innerWidth >= 768;
            
            if (wasDesktop !== this.isDesktop) {
                this.onViewportChange();
            }
        });
    }

    bindEvents() {
        
        // Navigation Overlay Events
        this.bindNavigationEvents();
        
        // Main Content Section Click Events
        document.querySelectorAll('.section').forEach(section => {
            section.addEventListener('click', (e) => {
                this.handleSectionClick(e);
            });
        });
    }

    bindNavigationEvents() {
        // Nav Toggle Button (Header)
        const navToggle = document.getElementById('nav-toggle');
        const navOverlay = document.getElementById('nav-overlay');
        const navCloseBtn = document.getElementById('nav-close-btn');
        
        if (navToggle && navOverlay) {
            navToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleNavigation();
            });
        }
        
        if (navCloseBtn && navOverlay) {
            navCloseBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeNavigation();
            });
        }
        
        // Close nav when clicking overlay background
        if (navOverlay) {
            navOverlay.addEventListener('click', (e) => {
                if (e.target === navOverlay) {
                    this.closeNavigation();
                }
            });
        }
        
        // ESC key to close navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeNavigation();
            }
        });

        // Dropdown menu functionality
        this.bindDropdownEvents();
        
        // Scroll navigation functionality
        this.bindScrollEvents();
        
        // Library tab switching functionality
        this.bindLibraryTabEvents();
    }

    bindDropdownEvents() {
        const libraryToggle = document.getElementById('library-toggle');
        const librarySubmenu = document.getElementById('library-submenu');
        const libraryArrow = document.getElementById('library-arrow');
        
        if (libraryToggle && librarySubmenu && libraryArrow) {
            libraryToggle.addEventListener('click', (e) => {
                e.preventDefault();
                const isOpen = !librarySubmenu.classList.contains('hidden');
                
                if (isOpen) {
                    librarySubmenu.classList.add('hidden');
                    libraryArrow.classList.remove('rotate-180');
                } else {
                    librarySubmenu.classList.remove('hidden');
                    libraryArrow.classList.add('rotate-180');
                }
            });
        }
    }

    bindScrollEvents() {
        // Main menu scroll events
        const menuItems = document.querySelectorAll('.nav-menu-item[data-scroll-target]');
        menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = item.getAttribute('data-scroll-target');
                this.scrollToSection(targetId);
            });
        });

        // Submenu scroll events
        const submenuItems = document.querySelectorAll('.nav-submenu-item[data-scroll-target]');
        submenuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = item.getAttribute('data-scroll-target');
                this.scrollToSection(targetId);
            });
        });
    }

    scrollToSection(targetId) {
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
            // Close navigation first
            this.closeNavigation();
            
            // Scroll to target with header offset
            const headerHeight = 97.36; // Fixed header height
            const elementPosition = targetElement.offsetTop;
            const offsetPosition = elementPosition - headerHeight;
            
            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
    }

    bindLibraryTabEvents() {
        // Get all library tab buttons (both desktop and mobile) - HTML基準構造対応
        const tabButtons = document.querySelectorAll('.library-tab-btn[data-tab]');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const selectedTab = button.getAttribute('data-tab');
                this.switchLibraryTab(selectedTab);
            });
        });
        
        // Initialize with Tokyo tab selected
        this.switchLibraryTab('tokyo');
    }

    switchLibraryTab(selectedTab) {
        // Update button states - HTML基準CSS適用
        const allTabButtons = document.querySelectorAll('.library-tab-btn[data-tab]');
        allTabButtons.forEach(button => {
            const tabName = button.getAttribute('data-tab');
            const isSelected = tabName === selectedTab;
            
            if (isSelected) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });
        
        // Update title images visibility - HTML基準ID対応
        const tokyoTitleDesktop = document.getElementById('lib-title-tokyo');
        const osakaTitleDesktop = document.getElementById('lib-title-osaka');
        const tokyoTitleMobile = document.getElementById('lib-title-tokyo-mobile');
        const osakaTitleMobile = document.getElementById('lib-title-osaka-mobile');
        
        if (selectedTab === 'tokyo') {
            // Show Tokyo titles
            if (tokyoTitleDesktop) tokyoTitleDesktop.classList.remove('hidden');
            if (osakaTitleDesktop) osakaTitleDesktop.classList.add('hidden');
            if (tokyoTitleMobile) tokyoTitleMobile.classList.remove('hidden');
            if (osakaTitleMobile) osakaTitleMobile.classList.add('hidden');
        } else {
            // Show Osaka titles  
            if (tokyoTitleDesktop) tokyoTitleDesktop.classList.add('hidden');
            if (osakaTitleDesktop) osakaTitleDesktop.classList.remove('hidden');
            if (tokyoTitleMobile) tokyoTitleMobile.classList.add('hidden');
            if (osakaTitleMobile) osakaTitleMobile.classList.remove('hidden');
        }
        
        // Update dancers visibility - HTML基準ID対応
        const tokyoDancersDesktop = document.getElementById('tokyo-dancers');
        const osakaDancersDesktop = document.getElementById('osaka-dancers');
        const tokyoDancersMobile = document.getElementById('tokyo-dancers-mobile');
        const osakaDancersMobile = document.getElementById('osaka-dancers-mobile');
        
        if (selectedTab === 'tokyo') {
            // Show Tokyo dancers
            if (tokyoDancersDesktop) tokyoDancersDesktop.classList.remove('hidden');
            if (osakaDancersDesktop) osakaDancersDesktop.classList.add('hidden');
            if (tokyoDancersMobile) tokyoDancersMobile.classList.remove('hidden');
            if (osakaDancersMobile) osakaDancersMobile.classList.add('hidden');
        } else {
            // Show Osaka dancers
            if (tokyoDancersDesktop) tokyoDancersDesktop.classList.add('hidden');
            if (osakaDancersDesktop) osakaDancersDesktop.classList.remove('hidden');
            if (tokyoDancersMobile) tokyoDancersMobile.classList.add('hidden');
            if (osakaDancersMobile) osakaDancersMobile.classList.remove('hidden');
        }
        
    }

    toggleNavigation() {
        const navOverlay = document.getElementById('nav-overlay');
        if (navOverlay) {
            const isVisible = !navOverlay.classList.contains('hidden');
            if (isVisible) {
                this.closeNavigation();
            } else {
                this.openNavigation();
            }
        }
    }

    openNavigation() {
        const navOverlay = document.getElementById('nav-overlay');
        if (navOverlay) {
            navOverlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Prevent body scroll
        }
    }

    closeNavigation() {
        const navOverlay = document.getElementById('nav-overlay');
        if (navOverlay) {
            navOverlay.classList.add('hidden');
            document.body.style.overflow = ''; // Restore body scroll
        }
    }

    initMainContent() {
        
        // Add smooth scroll behavior for sections
        const sections = document.querySelectorAll('.section');
        sections.forEach((section, index) => {
            // Add section navigation functionality if needed
            section.setAttribute('data-section-index', index);
        });
        
        // Initialize Swiper sliders
        this.initSwiper();
    }

    initSwiper() {
        // Wait for Swiper to be available
        const waitForSwiper = () => {
            if (typeof Swiper !== 'undefined') {
                this.setupSwiperSliders();
            } else {
                setTimeout(waitForSwiper, 100);
            }
        };
        waitForSwiper();
    }

    setupSwiperSliders() {
        
        // Common Swiper Settings - HTML基準設定
        const commonSettings = {
            allowTouchMove: false,
            simulateTouch: false,
            slidesPerView: 'auto',
        };
        
        const mainSliderCommon = {
            ...commonSettings,
            rewind: true,
            speed: 1000,
            effect: 'slide',
            centeredSlides: true,
            initialSlide: 1,
            grabCursor: false,
            watchOverflow: false,
        };
        
        const logoSliderCommon = {
            ...commonSettings,
            speed: 15000,
            freeMode: {
                enabled: true,
                momentum: false,
            },
        };

        // Sponsor Section Swiper Initialization
        this.initSponsorSwipers(mainSliderCommon, logoSliderCommon);
    }

    initSponsorSwipers(mainSliderCommon, logoSliderCommon) {
        // Desktop Main Slider
        const mainSliderDesktopEl = document.querySelector('.main-slider-desktop');
        if (mainSliderDesktopEl) {
            this.mainSliderDesktop = new Swiper('.main-slider-desktop', {
                ...mainSliderCommon,
                loop: false,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                spaceBetween: 20,
            });
        }

        // Mobile Main Slider
        const mainSliderMobileEl = document.querySelector('.main-slider-mobile');
        if (mainSliderMobileEl) {
            this.mainSliderMobile = new Swiper('.main-slider-mobile', {
                ...mainSliderCommon,
                loop: false,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                spaceBetween: '4.17%',
            });
        }

        // Desktop Logo Slider
        const logoSliderDesktopEl = document.querySelector('.logo-slider-desktop');
        if (logoSliderDesktopEl) {
            this.logoSliderDesktop = new Swiper('.logo-slider-desktop', {
                ...logoSliderCommon,
                loop: true,
                autoplay: {
                    delay: 0,
                    disableOnInteraction: false,
                    reverseDirection: false,
                },
                spaceBetween: '1.41%',
            });
        }

        // Mobile Logo Slider
        const logoSliderMobileEl = document.querySelector('.logo-slider-mobile');
        if (logoSliderMobileEl) {
            this.logoSliderMobile = new Swiper('.logo-slider-mobile', {
                ...logoSliderCommon,
                loop: true,
                autoplay: {
                    delay: 0,
                    disableOnInteraction: false,
                    reverseDirection: false,
                },
                spaceBetween: '3.52%',
            });
        }
    }



    handleSectionClick(e) {
        const section = e.currentTarget;
        const nodeId = section.dataset.nodeId;
        const sectionName = section.classList.contains('whsj-section') ? 'WHSJ' :
                           section.classList.contains('lib-top-section') ? 'Library Top' :
                           section.classList.contains('lib-list-section') ? 'Library List' : 'Unknown';
        
        
        // Future: Add section-specific interactions
    }



    onViewportChange() {
        // CSS handles all responsive behavior via media queries
        
        // Destroy existing swipers
        this.destroySwipers();
        
        // Re-initialize swipers for new viewport
        setTimeout(() => {
            this.initSwiper();
        }, 300);
    }

    destroySwipers() {
        // Destroy Sponsor Section Swipers
        if (this.mainSliderDesktop) {
            this.mainSliderDesktop.destroy(true, true);
            this.mainSliderDesktop = null;
        }
        
        if (this.mainSliderMobile) {
            this.mainSliderMobile.destroy(true, true);
            this.mainSliderMobile = null;
        }
        
        if (this.logoSliderDesktop) {
            this.logoSliderDesktop.destroy(true, true);
            this.logoSliderDesktop = null;
        }
        
        if (this.logoSliderMobile) {
            this.logoSliderMobile.destroy(true, true);
            this.logoSliderMobile = null;
        }
    }

}

// Initialize on DOM Content Loaded
document.addEventListener('DOMContentLoaded', () => {
    window.stepjamreApp = new STEPJAMreApp();
    
});

// Export for potential future module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = STEPJAMreApp;
}