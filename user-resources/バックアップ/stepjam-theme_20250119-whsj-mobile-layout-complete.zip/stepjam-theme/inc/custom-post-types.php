<?php
/**
 * カスタム投稿タイプ・タクソノミー登録
 * 
 * @package STEPJAM_Theme
 */

// セキュリティ対策
if (!defined('ABSPATH')) {
    exit;
}

/**
 * dancer-libraryカスタム投稿タイプの登録
 */
function stepjam_register_dancer_library_post_type() {
    $labels = array(
        'name' => 'Dancer Libraries',
        'singular_name' => 'Dancer Library',
        'add_new' => '新しいダンサーを追加',
        'add_new_item' => '新しいダンサーライブラリを追加',
        'edit_item' => 'ダンサーライブラリを編集',
        'new_item' => '新しいダンサーライブラリ',
        'view_item' => 'ダンサーライブラリを表示',
        'search_items' => 'ダンサーライブラリを検索',
        'not_found' => 'ダンサーライブラリが見つかりません',
        'not_found_in_trash' => 'ゴミ箱にダンサーライブラリはありません'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
        'rest_base' => 'dancer-library',
        'query_var' => true,
        'rewrite' => array('slug' => 'dancer-library'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title', 'thumbnail', 'revisions'),
        'menu_icon' => 'dashicons-groups'
    );

    register_post_type('dancer-library', $args);
}
add_action('init', 'stepjam_register_dancer_library_post_type');

/**
 * dancer-locationタクソノミーの登録
 */
function stepjam_register_dancer_location_taxonomy() {
    $labels = array(
        'name' => 'Locations',
        'singular_name' => 'Location',
        'search_items' => 'ロケーションを検索',
        'all_items' => 'すべてのロケーション',
        'edit_item' => 'ロケーションを編集',
        'update_item' => 'ロケーションを更新',
        'add_new_item' => '新しいロケーションを追加',
        'new_item_name' => '新しいロケーション名'
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
        'show_tagcloud' => false,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'location',
            'with_front' => false,
            'hierarchical' => true
        )
    );

    register_taxonomy('dancer-location', array('dancer-library'), $args);
}
add_action('init', 'stepjam_register_dancer_location_taxonomy');

/**
 * デフォルトタームの作成
 */
function stepjam_create_default_dancer_locations() {
    // Tokyo タームの作成
    if (!term_exists('Tokyo', 'dancer-location')) {
        wp_insert_term(
            'Tokyo',
            'dancer-location',
            array(
                'slug' => 'tokyo',
                'description' => '東京エリアのダンサー'
            )
        );
    }

    // Osaka タームの作成
    if (!term_exists('Osaka', 'dancer-location')) {
        wp_insert_term(
            'Osaka',
            'dancer-location',
            array(
                'slug' => 'osaka',
                'description' => '大阪エリアのダンサー'
            )
        );
    }
}
add_action('init', 'stepjam_create_default_dancer_locations');

/**
 * dancer-library投稿のWP_Query取得関数
 */
function stepjam_get_dancers($location = '', $count = -1) {
    $args = array(
        'post_type' => 'dancer-library',
        'posts_per_page' => $count,
        'orderby' => 'rand',
        'post_status' => 'publish'
    );

    // ロケーション指定がある場合
    if (!empty($location)) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'dancer-location',
                'field' => 'slug',
                'terms' => $location
            )
        );
    }

    return new WP_Query($args);
}