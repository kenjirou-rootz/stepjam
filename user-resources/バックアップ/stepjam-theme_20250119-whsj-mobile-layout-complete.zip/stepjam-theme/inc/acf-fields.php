<?php
/**
 * ACFフィールド設定
 * 
 * @package STEPJAM_Theme
 */

// セキュリティ対策
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ACFオプションページの作成
 */
function stepjam_acf_add_options_page() {
    if (function_exists('acf_add_options_page')) {
        // Site Settings オプションページ
        acf_add_options_page(array(
            'page_title' => 'Site Settings',
            'menu_title' => 'サイト設定',
            'menu_slug' => 'site-settings',
            'capability' => 'edit_posts',
            'icon_url' => 'dashicons-admin-settings',
            'position' => 30
        ));
        
        // Sponsor Settings オプションページ
        acf_add_options_page(array(
            'page_title' => 'スポンサー設定',
            'menu_title' => 'スポンサー',
            'menu_slug' => 'sponsor-settings',
            'capability' => 'edit_posts',
            'icon_url' => 'dashicons-star-filled',
            'position' => 31
        ));

        // WHSJ Settings オプションページ
        acf_add_options_page(array(
            'page_title' => 'WHSJ設定',
            'menu_title' => 'WHSJ',
            'menu_slug' => 'whsj-settings',
            'capability' => 'edit_posts',
            'icon_url' => 'dashicons-video-alt3',
            'position' => 32
        ));
    }
}
add_action('acf/init', 'stepjam_acf_add_options_page');

/**
 * ACFフィールドグループの登録
 */
function stepjam_register_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    // 1. Hero Section フィールドグループ
    acf_add_local_field_group(array(
        'key' => 'group_hero_section',
        'title' => 'Hero Section',
        'fields' => array(
            array(
                'key' => 'field_hero_logo',
                'label' => 'Hero Logo',
                'name' => 'hero_logo',
                'type' => 'image',
                'instructions' => 'Hero セクションで表示するロゴ画像',
                'return_format' => 'url',
                'preview_size' => 'medium',
                'library' => 'all',
                'min_width' => 300,
                'min_height' => 50
            ),
            array(
                'key' => 'field_hero_logo_alt',
                'label' => 'Hero Logo Alt Text',
                'name' => 'hero_logo_alt',
                'type' => 'text',
                'instructions' => 'ロゴ画像の代替テキスト',
                'default_value' => 'STEPJAM'
            ),
            array(
                'key' => 'field_hero_display_settings',
                'label' => '表示設定',
                'name' => 'hero_display_settings',
                'type' => 'true_false',
                'instructions' => 'Hero セクションを表示するかどうか',
                'default_value' => 1
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'front-page.php'
                )
            )
        ),
        'position' => 'acf_after_title',
        'style' => 'default'
    ));

    // 2. Library Section フィールドグループ
    acf_add_local_field_group(array(
        'key' => 'group_library_section',
        'title' => 'Library Section',
        'fields' => array(
            array(
                'key' => 'field_lib_title_tokyo',
                'label' => 'Library Title Tokyo',
                'name' => 'lib_title_tokyo',
                'type' => 'image',
                'instructions' => 'Tokyo エリア用のタイトル画像',
                'return_format' => 'url',
                'preview_size' => 'medium'
            ),
            array(
                'key' => 'field_lib_title_osaka',
                'label' => 'Library Title Osaka',
                'name' => 'lib_title_osaka',
                'type' => 'image',
                'instructions' => 'Osaka エリア用のタイトル画像',
                'return_format' => 'url',
                'preview_size' => 'medium'
            ),
            array(
                'key' => 'field_lib_top_tokyo_image',
                'label' => 'Library Top Tokyo Image',
                'name' => 'lib_top_tokyo_image',
                'type' => 'image',
                'instructions' => 'Library Top セクション用の東京エリア画像',
                'return_format' => 'url',
                'preview_size' => 'medium'
            ),
            array(
                'key' => 'field_lib_top_osaka_svg',
                'label' => 'Library Top Osaka SVG',
                'name' => 'lib_top_osaka_svg',
                'type' => 'file',
                'instructions' => 'Library Top セクション用の大阪エリアSVG',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'svg'
            ),
            array(
                'key' => 'field_lib_center_divider',
                'label' => 'Library Center Divider',
                'name' => 'lib_center_divider',
                'type' => 'file',
                'instructions' => 'Library Top セクション用の中央区切りSVG',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'svg'
            ),
            array(
                'key' => 'field_lib_display_settings',
                'label' => 'Display Settings',
                'name' => 'lib_display_settings',
                'type' => 'group',
                'instructions' => 'ライブラリ表示の詳細設定',
                'sub_fields' => array(
                    array(
                        'key' => 'field_cards_per_row',
                        'label' => 'Cards Per Row',
                        'name' => 'cards_per_row',
                        'type' => 'number',
                        'instructions' => '1行に表示するカード数',
                        'default_value' => 4,
                        'min' => 1,
                        'max' => 8
                    ),
                    array(
                        'key' => 'field_show_count',
                        'label' => 'Show Count',
                        'name' => 'show_count',
                        'type' => 'true_false',
                        'instructions' => 'カード数を表示するかどうか',
                        'default_value' => 1
                    )
                )
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'front-page.php'
                )
            )
        ),
        'position' => 'acf_after_title'
    ));

    // 4. WHSJ Section フィールドグループ（オプションページ対応・簡略化）
    acf_add_local_field_group(array(
        'key' => 'group_whsj_options',
        'title' => 'WHSJ Settings',
        'fields' => array(
            array(
                'key' => 'field_whsj_video',
                'label' => 'WHSJ Video',
                'name' => 'whsj_video',
                'type' => 'file',
                'instructions' => 'デスクトップ・モバイル共通のWHSJ動画ファイル',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov'
            ),
            array(
                'key' => 'field_whsj_text_content',
                'label' => 'WHSJ Text Content',
                'name' => 'whsj_text_content',
                'type' => 'textarea',
                'instructions' => 'WHSJセクションのテキストコンテンツ',
                'rows' => 8
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'whsj-settings'
                )
            )
        ),
        'position' => 'acf_after_title'
    ));

    // 4. Sponsor Section フィールドグループ
    acf_add_local_field_group(array(
        'key' => 'group_sponsor_section',
        'title' => 'Sponsor Section',
        'fields' => array(
            // Tab: Main Slider Videos
            array(
                'key' => 'field_sponsor_main_videos_tab',
                'label' => 'メインスライダー動画',
                'name' => 'sponsor_main_videos_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーセクションのメインスライダー用動画（3本）'
            ),
            array(
                'key' => 'field_sponsor_main_video_01',
                'label' => 'メインスライダー動画 1',
                'name' => 'sponsor_main_video_01',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの1番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            array(
                'key' => 'field_sponsor_main_video_02',
                'label' => 'メインスライダー動画 2',
                'name' => 'sponsor_main_video_02',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの2番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            array(
                'key' => 'field_sponsor_main_video_03',
                'label' => 'メインスライダー動画 3',
                'name' => 'sponsor_main_video_03',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの3番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            
            // Tab: Logo Slider
            array(
                'key' => 'field_sponsor_logos_tab',
                'label' => 'ロゴスライダー',
                'name' => 'sponsor_logos_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーロゴスライダー用画像（複数登録可能）'
            ),
            array(
                'key' => 'field_sponsor_logos',
                'label' => 'スポンサーロゴ',
                'name' => 'sponsor_logos',
                'type' => 'repeater',
                'instructions' => 'スポンサーロゴ画像を追加してください。画像は自動的にスライダー表示されます。',
                'sub_fields' => array(
                    array(
                        'key' => 'field_sponsor_logo_image',
                        'label' => 'ロゴ画像',
                        'name' => 'sponsor_logo_image',
                        'type' => 'image',
                        'instructions' => 'スポンサーロゴ画像（推奨サイズ: 564px × 255px）',
                        'required' => 1,
                        'return_format' => 'array',
                        'preview_size' => 'medium',
                        'library' => 'all',
                        'min_width' => 200,
                        'min_height' => 100
                    ),
                    array(
                        'key' => 'field_sponsor_logo_alt',
                        'label' => '代替テキスト',
                        'name' => 'sponsor_logo_alt',
                        'type' => 'text',
                        'instructions' => 'ロゴ画像の代替テキスト（空の場合は自動生成）',
                        'required' => 0
                    ),
                    array(
                        'key' => 'field_sponsor_logo_url',
                        'label' => 'リンクURL',
                        'name' => 'sponsor_logo_url',
                        'type' => 'url',
                        'instructions' => 'ロゴクリック時のリンク先URL（任意）',
                        'required' => 0
                    ),
                    array(
                        'key' => 'field_sponsor_logo_target',
                        'label' => 'リンクターゲット',
                        'name' => 'sponsor_logo_target',
                        'type' => 'select',
                        'instructions' => 'リンク先の開き方',
                        'choices' => array(
                            '_self' => '同じウィンドウで開く',
                            '_blank' => '新しいウィンドウで開く'
                        ),
                        'default_value' => '_blank',
                        'conditional_logic' => array(
                            array(
                                array(
                                    'field' => 'field_sponsor_logo_url',
                                    'operator' => '!=',
                                    'value' => ''
                                )
                            )
                        )
                    )
                ),
                'min' => 0,
                'max' => 10,
                'layout' => 'block',
                'button_label' => 'スポンサーロゴを追加',
                'collapsed' => 'field_sponsor_logo_image'
            ),
            
            // Tab: Display Settings
            array(
                'key' => 'field_sponsor_display_tab',
                'label' => '表示設定',
                'name' => 'sponsor_display_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーセクションの表示設定'
            ),
            array(
                'key' => 'field_sponsor_section_enabled',
                'label' => 'スポンサーセクションを表示',
                'name' => 'sponsor_section_enabled',
                'type' => 'true_false',
                'instructions' => 'スポンサーセクション全体の表示・非表示を切り替え',
                'default_value' => 1,
                'ui' => 1
            ),
            array(
                'key' => 'field_sponsor_autoplay_enabled',
                'label' => '動画自動再生',
                'name' => 'sponsor_autoplay_enabled',
                'type' => 'true_false',
                'instructions' => 'メインスライダー動画の自動再生設定',
                'default_value' => 1,
                'ui' => 1
            ),
            array(
                'key' => 'field_sponsor_slider_speed',
                'label' => 'スライダー速度（ms）',
                'name' => 'sponsor_slider_speed',
                'type' => 'number',
                'instructions' => 'メインスライダーの切り替え速度（ミリ秒）',
                'default_value' => 3000,
                'min' => 1000,
                'max' => 10000,
                'step' => 500
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'front-page.php'
                )
            )
        ),
        'position' => 'acf_after_title',
        'style' => 'default'
    ));

    // 5. Dancer Profile フィールドグループ（dancer-library投稿用）
    acf_add_local_field_group(array(
        'key' => 'group_dancer_profile',
        'title' => 'Dancer Profile',
        'fields' => array(
            array(
                'key' => 'field_dancer_image',
                'label' => 'Profile Image',
                'name' => 'dancer_image',
                'type' => 'image',
                'instructions' => 'ダンサーのプロフィール画像',
                'required' => 1,
                'return_format' => 'url',
                'preview_size' => 'medium',
                'library' => 'all'
            ),
            array(
                'key' => 'field_dancer_display_name',
                'label' => 'Display Name',
                'name' => 'dancer_display_name',
                'type' => 'text',
                'instructions' => 'ダンサーの表示名（空の場合は投稿タイトルを使用）'
            ),
            array(
                'key' => 'field_dancer_profile',
                'label' => 'Profile Text',
                'name' => 'dancer_profile',
                'type' => 'textarea',
                'instructions' => 'ダンサーのプロフィール説明',
                'rows' => 4
            ),
            array(
                'key' => 'field_social_links',
                'label' => 'Social Links',
                'name' => 'social_links',
                'type' => 'repeater',
                'instructions' => 'ソーシャルメディアリンク',
                'sub_fields' => array(
                    array(
                        'key' => 'field_social_platform',
                        'label' => 'Platform',
                        'name' => 'social_platform',
                        'type' => 'select',
                        'choices' => array(
                            'instagram' => 'Instagram',
                            'twitter' => 'Twitter',
                            'youtube' => 'YouTube',
                            'tiktok' => 'TikTok'
                        ),
                        'default_value' => 'instagram'
                    ),
                    array(
                        'key' => 'field_social_url',
                        'label' => 'URL',
                        'name' => 'social_url',
                        'type' => 'url',
                        'required' => 1
                    ),
                    array(
                        'key' => 'field_social_icon',
                        'label' => 'Icon',
                        'name' => 'social_icon',
                        'type' => 'image',
                        'return_format' => 'url',
                        'preview_size' => 'thumbnail'
                    )
                ),
                'min' => 0,
                'max' => 5,
                'layout' => 'table',
                'button_label' => 'ソーシャルリンクを追加'
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'dancer-library'
                )
            )
        ),
        'position' => 'acf_after_title'
    ));

    // 6. Site Options フィールドグループ（オプションページ用）
    acf_add_local_field_group(array(
        'key' => 'group_site_options',
        'title' => 'Site Options',
        'fields' => array(
            // Header Section
            array(
                'key' => 'field_header_section',
                'label' => 'Header Settings',
                'name' => 'header_settings',
                'type' => 'tab',
                'placement' => 'top'
            ),
            array(
                'key' => 'field_header_logo',
                'label' => 'Header Logo',
                'name' => 'header_logo',
                'type' => 'image',
                'instructions' => 'ヘッダーで使用するロゴ画像',
                'return_format' => 'url',
                'preview_size' => 'medium'
            ),
            array(
                'key' => 'field_nav_icon',
                'label' => 'Navigation Icon',
                'name' => 'nav_icon',
                'type' => 'image',
                'instructions' => 'ナビゲーションメニューのアイコン',
                'return_format' => 'url',
                'preview_size' => 'thumbnail'
            ),
            
            // Footer Section
            array(
                'key' => 'field_footer_section',
                'label' => 'Footer Settings',
                'name' => 'footer_settings',
                'type' => 'tab',
                'placement' => 'top'
            ),
            array(
                'key' => 'field_footer_logo_ve',
                'label' => 'Footer Logo VE',
                'name' => 'footer_logo_ve',
                'type' => 'image',
                'instructions' => 'フッターVEロゴ',
                'return_format' => 'url'
            ),
            array(
                'key' => 'field_footer_logo_main',
                'label' => 'Footer Logo Main',
                'name' => 'footer_logo_main',
                'type' => 'image',
                'instructions' => 'フッターメインロゴ',
                'return_format' => 'url'
            ),
            
            // Contact Information
            array(
                'key' => 'field_contact_section',
                'label' => 'Contact Information',
                'name' => 'contact_information',
                'type' => 'tab',
                'placement' => 'top'
            ),
            array(
                'key' => 'field_company_name',
                'label' => 'Company Name',
                'name' => 'company_name',
                'type' => 'text',
                'default_value' => 'STEPJAM'
            ),
            array(
                'key' => 'field_company_address',
                'label' => 'Company Address',
                'name' => 'company_address',
                'type' => 'textarea',
                'rows' => 3
            ),
            array(
                'key' => 'field_contact_email',
                'label' => 'Contact Email',
                'name' => 'contact_email',
                'type' => 'email'
            ),
            array(
                'key' => 'field_privacy_policy_url',
                'label' => 'Privacy Policy URL',
                'name' => 'privacy_policy_url',
                'type' => 'url'
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'site-settings'
                )
            )
        ),
        'position' => 'normal'
    ));

    // 7. Sponsor Settings フィールドグループ（オプションページ用）
    acf_add_local_field_group(array(
        'key' => 'group_sponsor_settings',
        'title' => 'スポンサー設定',
        'fields' => array(
            // Tab: Main Slider Videos
            array(
                'key' => 'field_sponsor_settings_main_videos_tab',
                'label' => 'メインスライダー動画',
                'name' => 'sponsor_settings_main_videos_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーセクションのメインスライダー用動画（3本）'
            ),
            array(
                'key' => 'field_sponsor_settings_main_video_01',
                'label' => 'メインスライダー動画 1',
                'name' => 'sponsor_main_video_01',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの1番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            array(
                'key' => 'field_sponsor_settings_main_video_02',
                'label' => 'メインスライダー動画 2',
                'name' => 'sponsor_main_video_02',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの2番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            array(
                'key' => 'field_sponsor_settings_main_video_03',
                'label' => 'メインスライダー動画 3',
                'name' => 'sponsor_main_video_03',
                'type' => 'file',
                'instructions' => 'スポンサーメインスライダーの3番目の動画',
                'return_format' => 'url',
                'library' => 'all',
                'mime_types' => 'mp4,webm,mov',
                'required' => 0
            ),
            
            // Tab: Logo Slider
            array(
                'key' => 'field_sponsor_settings_logos_tab',
                'label' => 'ロゴスライダー',
                'name' => 'sponsor_settings_logos_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーロゴスライダー用画像（複数登録可能）'
            ),
            array(
                'key' => 'field_sponsor_settings_logos',
                'label' => 'スポンサーロゴ',
                'name' => 'sponsor_logos',
                'type' => 'repeater',
                'instructions' => 'スポンサーロゴ画像を追加してください。画像は自動的にスライダー表示されます。',
                'sub_fields' => array(
                    array(
                        'key' => 'field_sponsor_settings_logo_image',
                        'label' => 'ロゴ画像',
                        'name' => 'sponsor_logo_image',
                        'type' => 'image',
                        'instructions' => 'スポンサーロゴ画像（推奨サイズ: 564px × 255px）',
                        'required' => 1,
                        'return_format' => 'array',
                        'preview_size' => 'medium',
                        'library' => 'all',
                        'min_width' => 200,
                        'min_height' => 100
                    ),
                    array(
                        'key' => 'field_sponsor_settings_logo_alt',
                        'label' => '代替テキスト',
                        'name' => 'sponsor_logo_alt',
                        'type' => 'text',
                        'instructions' => 'ロゴ画像の代替テキスト（空の場合は自動生成）',
                        'required' => 0
                    ),
                    array(
                        'key' => 'field_sponsor_settings_logo_url',
                        'label' => 'リンクURL',
                        'name' => 'sponsor_logo_url',
                        'type' => 'url',
                        'instructions' => 'ロゴクリック時のリンク先URL（任意）',
                        'required' => 0
                    ),
                    array(
                        'key' => 'field_sponsor_settings_logo_target',
                        'label' => 'リンクターゲット',
                        'name' => 'sponsor_logo_target',
                        'type' => 'select',
                        'instructions' => 'リンク先の開き方',
                        'choices' => array(
                            '_self' => '同じウィンドウで開く',
                            '_blank' => '新しいウィンドウで開く'
                        ),
                        'default_value' => '_blank',
                        'conditional_logic' => array(
                            array(
                                array(
                                    'field' => 'field_sponsor_settings_logo_url',
                                    'operator' => '!=',
                                    'value' => ''
                                )
                            )
                        )
                    )
                ),
                'min' => 0,
                'max' => 10,
                'layout' => 'block',
                'button_label' => 'スポンサーロゴを追加',
                'collapsed' => 'field_sponsor_settings_logo_image'
            ),
            
            // Tab: Display Settings
            array(
                'key' => 'field_sponsor_settings_display_tab',
                'label' => '表示設定',
                'name' => 'sponsor_settings_display_tab',
                'type' => 'tab',
                'placement' => 'top',
                'instructions' => 'スポンサーセクションの表示設定'
            ),
            array(
                'key' => 'field_sponsor_settings_section_enabled',
                'label' => 'スポンサーセクションを表示',
                'name' => 'sponsor_section_enabled',
                'type' => 'true_false',
                'instructions' => 'スポンサーセクション全体の表示・非表示を切り替え',
                'default_value' => 1,
                'ui' => 1
            ),
            array(
                'key' => 'field_sponsor_settings_autoplay_enabled',
                'label' => '動画自動再生',
                'name' => 'sponsor_autoplay_enabled',
                'type' => 'true_false',
                'instructions' => 'メインスライダー動画の自動再生設定',
                'default_value' => 1,
                'ui' => 1
            ),
            array(
                'key' => 'field_sponsor_settings_slider_speed',
                'label' => 'スライダー速度（ms）',
                'name' => 'sponsor_slider_speed',
                'type' => 'number',
                'instructions' => 'メインスライダーの切り替え速度（ミリ秒）',
                'default_value' => 3000,
                'min' => 1000,
                'max' => 10000,
                'step' => 500
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'sponsor-settings'
                )
            )
        ),
        'position' => 'normal',
        'style' => 'default'
    ));
}
add_action('acf/init', 'stepjam_register_acf_fields');

/**
 * ACFフィールド値取得のヘルパー関数
 */
function stepjam_get_site_option($field_name, $default = '') {
    if (function_exists('get_field')) {
        $value = get_field($field_name, 'option');
        return $value ?: $default;
    }
    return $default;
}

/**
 * dancer-library投稿の取得関数（ACF対応）
 */
function stepjam_get_dancers_with_acf($location = '', $count = -1) {
    $args = array(
        'post_type' => 'dancer-library',
        'posts_per_page' => $count,
        'orderby' => 'rand',
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => 'dancer_image',
                'compare' => 'EXISTS'
            )
        )
    );

    // ロケーション指定がある場合
    if (!empty($location)) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'dancer-location',
                'field' => 'slug',
                'terms' => $location
            )
        );
    }

    return new WP_Query($args);
}