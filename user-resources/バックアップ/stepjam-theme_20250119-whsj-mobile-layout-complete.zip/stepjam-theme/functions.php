<?php
/**
 * STEPJAM Theme Functions
 * 
 * @package STEPJAM_Theme
 * @version 1.0.0
 */

// セキュリティ対策
if (!defined('ABSPATH')) {
    exit;
}

/**
 * テーマセットアップ
 */
function stepjam_theme_setup() {
    // タイトルタグサポート
    add_theme_support('title-tag');
    
    // アイキャッチ画像サポート
    add_theme_support('post-thumbnails');
    
    // HTML5サポート
    add_theme_support('html5', array(
        'comment-list',
        'comment-form',
        'search-form',
        'gallery',
        'caption',
        'style',
        'script'
    ));
    
    // カスタムメニューサポート
    register_nav_menus(array(
        'primary' => 'メインメニュー',
        'footer' => 'フッターメニュー'
    ));
    
    // レスポンシブ埋め込みサポート
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'stepjam_theme_setup');

/**
 * 機能ファイルの読み込み
 */
$includes = array(
    '/inc/enqueue-scripts.php',      // CSS/JS読み込み
    '/inc/custom-post-types.php',    // カスタム投稿タイプ
    '/inc/acf-fields.php'           // ACFフィールド設定
);

foreach ($includes as $file) {
    if (file_exists(get_template_directory() . $file)) {
        require_once get_template_directory() . $file;
    }
}

/**
 * テーマカスタマイズ
 */
function stepjam_customize_register($wp_customize) {
    // 必要に応じてカスタマイザー設定を追加
    // 現在は基本構造のみ
}
add_action('customize_register', 'stepjam_customize_register');

/**
 * ウィジェットエリア登録
 */
function stepjam_widgets_init() {
    register_sidebar(array(
        'name'          => 'フッターウィジェット',
        'id'            => 'footer-widget',
        'description'   => 'フッター領域のウィジェット',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'stepjam_widgets_init');

/**
 * デバッグ用関数（開発時のみ）
 */
if (WP_DEBUG) {
    function stepjam_debug_log($message) {
        if (is_array($message) || is_object($message)) {
            error_log('[STEPJAM_DEBUG] ' . print_r($message, true));
        } else {
            error_log('[STEPJAM_DEBUG] ' . $message);
        }
    }
}