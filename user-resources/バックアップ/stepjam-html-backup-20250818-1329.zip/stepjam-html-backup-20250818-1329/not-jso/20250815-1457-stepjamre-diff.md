# STEPJAMre 実装差分記録

## 実装日時
2025-08-15 14:57

## 実装概要
- **方式**: Tailwind CSS ユーティリティファースト
- **MCP経由取得**: Figma APIから直接データ取得
- **ACF対応**: WordPress ACF用のdata属性付与

## Figmaデータ取得記録

### デスクトップフレーム (Node: 154:139)
- **サイズ**: 1920px × 5000px
- **座標**: x:1815, y:-1993

### モバイルフレーム (Node: 154:141)  
- **サイズ**: 768px × 5000px
- **座標**: x:4447, y:-1993

### ヘッダー要素
- **nav-bt_close (114:7294)**: 173.08px × 97.36px
- **sjlogo (114:7295)**: 96.67px × 21.47px
- **間隔**: 44px (itemSpacing)

### ACF要素検出
- acf-cust-post (カスタム投稿)
- acf-custpost-img (画像)
- acf-custpost-tx (テキスト)
- acf-spon-sl (スポンサースライダー)
- acf-tag-bt (タグボタン)

## 実装技術仕様

### Tailwind CSS設定
```javascript
tailwind.config = {
    theme: {
        extend: {
            colors: {
                'figma-black': '#000000',
                'figma-white': '#FFFFFF',
                'figma-cyan': '#00F7FF',
            },
            width: {
                'nav': '173.08px',
                'logo': '96.67px',
                'desktop': '1920px',
                'mobile': '768px',
            },
            height: {
                'nav': '97.36px',
                'logo': '21.47px',
                'footer': '152px',
            }
        }
    }
}
```

### レスポンシブブレイクポイント
- Desktop: ≥768px (実際は1920px想定)
- Mobile: ≤768px

### ACF対応構造
- `data-acf="*"` 属性でWordPress化時の置換対象を明示
- セクション単位での分離
- 動的コンテンツエリアの明確化

## 次回作業時の注意事項
- ローカルJSONは使用せず、MCPまたはREST API経由でのみデータ取得
- Figmaの実際の寸法値を必ず確認
- ACF要素は必ずdata-acf属性で管理