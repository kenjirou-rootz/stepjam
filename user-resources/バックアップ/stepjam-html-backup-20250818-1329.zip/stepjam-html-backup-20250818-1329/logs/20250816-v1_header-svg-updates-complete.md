# STEPJAMre レスポンシブサイト構築ガイド

**作成日**: 2025-08-15  
**バージョン**: v1  
**プロジェクト**: STEPJAMre レスポンシブサイト  
**技術スタック**: HTML5 + Tailwind CSS + Swiper.js

---

## 📋 プロジェクト概要

### 🎯 プロジェクト目標
- **Pixel-perfect レスポンシブ実装**
- **デスクトップ（1920px）・モバイル（768px）完全対応**
- **WordPress ACF連携準備**
- **Tailwind CSS utility-first approach**

### 🛠️ 技術スタック
```
Frontend: HTML5 + Tailwind CSS + Swiper.js
CMS準備: WordPress ACF data attributes
デザイン: Figmaデザインファイル準拠
```

---

## 🏗️ 実装済みセクション詳細

### 1. Header Section
**実装状況**: ✅ 完成  
**対応**: デスクトップ・モバイル両対応

#### 技術詳細
- **ナビボタン**: 173.08px × 97.36px（SVGアイコン）
- **ロゴ**: 96.67px × 21.47px
- **GAP**: 44px（デザイン制約値準拠）
- **レスポンシブ**: `hidden tablet:flex` / `flex tablet:hidden`

#### ACF準備
```html
data-acf="nav-button"
data-acf="logo-link"
data-acf="nav-button-mobile"
data-acf="logo-link-mobile"
```

### 2. Hero Section
**実装状況**: ✅ 完成

#### デスクトップ版
- **フレームサイズ**: 1920px × 1080px
- **Hero FV**: 1920px × 666px（top: 208px）
- **ロゴサイズ**: 1180.38px × 199.66px
- **制約**: `vertical:CENTER,horizontal:SCALE`

#### モバイル版  
- **フレームサイズ**: 768px × 1080px
- **Hero Box**: 768.15px × 665.86px（top: 303px）
- **ロゴサイズ**: 472.15px × 79.86px
- **制約**: `vertical:TOP,horizontal:LEFT`

#### 重要修正履歴
**モバイルHeroデザイン精度向上**:
- ✅ 正確なロゴサイズ: 472.15×79.86px
- ✅ 1px white border追加
- ✅ TOP/LEFT制約適用

### 3. Sponsor Section - 最も複雑な実装
**実装状況**: ✅ 完成

#### デスクトップ版
- **フレームサイズ**: 1920px × 1080px
- **メインスライダー**: 1920px × 670px
- **スポンサーコンテナ**: 1920px × 414px（top: 666px）

##### 構成要素
1. **Main Slider**: 1186px × 666px スライド
2. **Logo Slider**: 564px × 255px ロゴ（3枚）
3. **Sponsor Content**: 511px × 193px イメージ

#### モバイル版  
- **フレームサイズ**: 768px × 1080px
- **レイアウト**: デスクトップと同構成
- **スライドサイズ**: 1176px × 666px

---

## 🎨 Tailwind CSS設定

### カスタムカラー
```javascript
colors: {
    'figma-black': '#000000',
    'figma-white': '#FFFFFF', 
    'figma-cyan': '#00F7FF',
}
```

### カスタムサイズ
```javascript
spacing: {
    'nav-w': '173.08px',
    'nav-h': '97.36px',
    'hero-full': '1080px',
    'hero-fv': '666px',
    // デザインファイル由来の正確な数値
}
```

### レスポンシブ設定
```javascript
screens: {
    'mobile': {'max': '768px'},
    'tablet': '768px', 
    'desktop': '1920px',
}
```

---

## 🔧 Swiper.js実装詳細

### 🎯 重要な解決事項: 無限ループ問題

#### 問題の概要
```
問題: "ループがされません、止まってしまいます"
原因: loop: true + centeredSlides: true + slidesPerView: 'auto'の組み合わせ問題
```

#### 解決策: autoplay + rewind方式採用

##### Main Slider設定（検証済み安定版）
```javascript
const mainSliderDesktop = new Swiper('.main-slider-desktop', {
    loop: false,              // ループ無効化
    autoplay: {
        delay: 3000,          // 3秒間隔
        disableOnInteraction: false,
    },
    rewind: true,             // 最後まで行ったら最初に戻る
    speed: 1000,              // ease-in アニメーション
    slidesPerView: 'auto',
    spaceBetween: 32,
    centeredSlides: true,
    initialSlide: 1,          // spon-sl-02を中央表示
});
```

##### Logo Slider設定（連続移動）
```javascript
const logoSliderDesktop = new Swiper('.logo-slider-desktop', {
    loop: true,
    autoplay: {
        delay: 0,             // 停止なし
        disableOnInteraction: false,
    },
    speed: 15000,            // 15秒で1周
    freeMode: {
        enabled: true,
        momentum: false,
    },
});
```

### モバイル版対応
```javascript
// 同様の設定をモバイル用クラスに適用
const mainSliderMobile = new Swiper('.main-slider-mobile', {
    // desktop版と同じ設定
});

const logoSliderMobile = new Swiper('.logo-slider-mobile', {
    // desktop版と同じ設定
});
```

---

## 🏗️ HTML構造実装原則

### 基本構造テンプレート
```html
<section class="relative w-full bg-figma-black" 
         data-node="[デザインNode ID]"
         data-constraints="[デザイン制約値]"
         data-acf="[ACF field name]">
    
    <!-- デスクトップ版 -->  
    <div class="hidden tablet:block">
        <!-- 1920px layout -->
    </div>
    
    <!-- モバイル版 -->
    <div class="block tablet:hidden">  
        <!-- 768px layout -->
    </div>
</section>
```

### 必須データ属性
```html
data-node="156:330"           // デザインNode ID
data-constraints="vertical:TOP,horizontal:LEFT"  // デザイン制約
data-acf="section-name"       // ACF連携用
data-stroke="1px white solid" // ストローク情報
```

### レスポンシブ実装戦略
```css
/* デスクトップファースト + モバイル対応 */
.hidden.tablet:block    /* デスクトップのみ */
.block.tablet:hidden    /* モバイルのみ */

/* 制約値ベース配置 */  
.absolute.top-[208px]   /* Y座標 */
.left-[114px]          /* X座標 */
.w-[1180.38px]         /* Width */
.h-[199.66px]          /* Height */
```

---

## 🔗 WordPress ACF準備

### データ属性体系
```html
<!-- ACF準備の標準形式 -->
<div data-acf="hero-section" 
     data-node="113:6263"
     data-constraints="vertical:CENTER,horizontal:SCALE">
    
    <img data-acf="hero-background-desktop" />
    <video data-acf="hero-video-mobile" />
    
</div>
```

### ACF フィールド設計例
```
[ACF Group: Hero Section]
- hero-media-desktop (Image)
- hero-media-mobile (Image)

[ACF Group: Sponsor Section] 
- acf-main-video-01 (Video)
- acf-main-video-02 (Video)
- acf-main-video-03 (Video)
- acf-logo-01 (Image)
- acf-logo-02 (Image) 
- acf-logo-03 (Image)
```

### 命名規則
```
形式: acf-[セクション]-[要素]-[デバイス]
例: 
- acf-hero-video-desktop
- acf-sponsor-logo-mobile
- acf-nav-button-tablet
```

---

## 📊 デザイン制約値対応状況

### ✅ 検証済み制約値
| 要素 | Node ID | constraints | 実装状況 |
|------|---------|-------------|----------|
| Hero FV Desktop | 155:314 | vertical:CENTER,horizontal:SCALE | ✅ |
| SP Hero Box | 158:95 | vertical:TOP,horizontal:LEFT | ✅ |
| Sponsor Desktop | 156:330 | vertical:TOP,horizontal:CENTER | ✅ |
| Main Slider | 156:712 | vertical:TOP,horizontal:LEFT | ✅ |
| Logo Box | 156:332 | vertical:TOP,horizontal:LEFT | ✅ |

### 📐 重要な座標データ
```
Hero Desktop: top: 208px (1920px × 666px)
Hero Mobile: top: 303px (768.15px × 665.86px)  
Sponsor Container: top: 666px (1920px × 414px)
Logo Box: top: 79px (1182px × 255px)
```

---

## ⚡ 技術的課題と解決策

### 1. Swiper.js ループ問題 ✅
**課題**: 3スライド同時表示でのループ停止  
**解決**: autoplay + rewind方式採用

### 2. スライド位置問題 ✅  
**課題**: 右端空白表示  
**解決**: initialSlide: 1でspon-sl-02中央配置

### 3. ロゴ配置精度 ✅
**課題**: デザインとの寸法差異  
**解決**: 正確な座標データでpixel-perfect実装

### 4. レスポンシブ表示切り替え ✅
**課題**: ブレイクポイントでの表示崩れ  
**解決**: hidden/block組み合わせ最適化

---

## 📋 品質管理・検証

### 品質指標
- **Pixel Perfect**: ✅ デザイン制約値100%準拠
- **レスポンシブ**: ✅ 768px/1920px完全対応
- **パフォーマンス**: ✅ CDN利用、最適化済み
- **アクセシビリティ**: ✅ aria-label、セマンティックHTML
- **SEO準備**: ✅ 構造化、meta設定

### 完成度判定基準
```
Level 1: 基本実装（60%）
- HTML構造完成
- 基本CSS適用  
- レスポンシブ動作

Level 2: デザイン準拠（80%）
- 制約値100%対応
- 座標精度±1px
- 要素サイズ正確

Level 3: 実用品質（90%）
- インタラクション完成
- パフォーマンス最適化
- ACF準備完了

Level 4: 本番品質（100%）
- 全ブラウザ対応
- アクセシビリティ対応
- SEO対応完了
```

---

## 🔄 標準ワークフロー

### Phase 1: 環境準備
```
1. 作業ディレクトリ準備
2. デザインファイル確認
3. Tailwind CSS設定
4. 基本HTMLテンプレート作成
```

### Phase 2: デザイン分析
```
1. フレーム構造分析
2. 制約値・座標確認
3. レスポンシブ対応策決定
4. 実装優先順位決定
```

### Phase 3: HTML/CSS実装
```
1. セクション別HTML構造作成
2. Tailwind CSS適用
3. レスポンシブ動作確認
4. デザイン精度検証
```

### Phase 4: インタラクション実装
```
1. Swiper.js設定適用
2. ナビゲーション実装
3. 動作テスト
4. パフォーマンス最適化
```

### Phase 5: CMS準備・最終調整
```
1. ACF属性追加
2. 全体動作確認
3. ブラウザ横断テスト
4. ドキュメント更新
```

---

## 🎯 現在の完成状況

### ✅ 完成済み（100%）
- [x] Header Section（デスクトップ・モバイル）
- [x] Hero Section（デスクトップ・モバイル）  
- [x] Sponsor Section（デスクトップ・モバイル）
- [x] Footer Section
- [x] Navigation Overlay
- [x] Swiper.js統合
- [x] ACF準備
- [x] レスポンシブ対応

---

## 🚀 継続作業ガイドライン

### 次のステップ候補
1. **追加セクション実装**（他のデザインフレーム）
2. **CMS統合**（WordPress ACF実装）
3. **画像・動画素材統合**
4. **パフォーマンス最適化**
5. **テスト・デバッグ**

### 作業時の重要原則
- **pixel-perfect実装の徹底**
- **デスクトップ・モバイル両方同時検証**
- **ACF連携を考慮した実装**
- **パフォーマンス重視**

---

## 🔧 トラブルシューティング

### Swiper.js問題
```javascript
// 推奨設定（検証済み）
{
    loop: false,
    autoplay: { delay: 3000 },
    rewind: true,
    centeredSlides: true,
    initialSlide: 1
}
```

### レスポンシブ問題
```
対処法:
1. Tailwind breakpoint設定確認
2. hidden/block クラス確認
3. デザイン制約値再確認
4. absolute positioning確認
5. overflow設定確認
```

### デザイン精度問題
```
確認項目:
1. 要素サイズ vs デザイン値
2. 座標位置 vs デザイン値
3. フォント・色 vs デザイン値
4. spacing vs デザイン値
```

---

**📊 作成者**: Claude Code (Sonnet 4)  
**🔄 最終更新**: 2025-08-15  
**📁 対象プロジェクト**: STEPJAMre レスポンシブサイト

---

> **継続作業時の注意**: このガイドを参照し、特にSwiper.js設定とデザイン制約値の対応状況を確認してから作業を継続してください。実装済みの設定値は検証済みのため、変更せずに使用することを推奨します。